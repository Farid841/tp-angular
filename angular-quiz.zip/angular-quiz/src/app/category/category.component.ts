import { Component, OnInit } from '@angular/core';
import { CategoryService } from './category.service';
import { Category } from './category.model';
import { ActivatedRoute, Router } from '@angular/router';

@Component({
  selector: 'app-category',
  templateUrl: './category.component.html',
  styleUrls: ['./category.component.scss'],
})
export class CategoryComponent implements OnInit {
  categoryInput: string = '';
  categories: Category[] = [];
  playerName: string = '';
  constructor(
    private router: Router,
    private route: ActivatedRoute,
    private categoryService: CategoryService
  ) {}
  ngOnInit() {
    this.getUserName();
    this.getCategories();
  }
  search() {
    this.categoryService
      .getCategoryByName(this.categoryInput)
      .subscribe((response) => {
        this.categories = response;
      });
  }
  resetFilter() {
    this.getCategories();
    this.categoryInput = '';
  }
  navigateToQuiz(category: Category) {
    this.router.navigate(['/quiz', this.playerName, category.name]);
  }
  private getCategories() {
    this.categoryService.getCategories().subscribe((response) => {
      this.categories = response;
    });
  }
  private getUserName() {
    this.route.params.subscribe((params) => {
      this.playerName = params['playerName'];
    });
  }
}
