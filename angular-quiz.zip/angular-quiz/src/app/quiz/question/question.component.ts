import { Component, Input, OnInit } from '@angular/core';
import { QuizService } from '../../shared/services/quiz.service';
import { CategoryService } from 'src/app/category/category.service';

@Component({
  selector: 'app-question',
  templateUrl: './question.component.html',
  styleUrls: ['./question.component.scss'],
})
export class QuestionComponent implements OnInit {
  quizContent: any[] = this.quizService.quizContent;

  constructor(private quizService: QuizService) {}

  ngOnInit(): void {
    this.quizService.getQuizContent(this.quizService.getCategory().id);
  }
}
