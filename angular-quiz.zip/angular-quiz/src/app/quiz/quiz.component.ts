import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { QuizService } from '../shared/services/quiz.service';
import { Category } from '../category/category.model';
import { CategoryService } from '../category/category.service';

@Component({
  selector: 'app-quiz',
  templateUrl: './quiz.component.html',
  styleUrls: ['./quiz.component.scss'],
})
export class QuizComponent implements OnInit {
  isQuizFinished = this.quizService.isQuizFinished;
  playerName = '';
  categoryName = '';

  constructor(
    private quizService: QuizService,
    private categoryService: CategoryService,
    private router: Router,
    private route: ActivatedRoute
  ) {}

  ngOnInit(): void {
    this.init();
  }

  goToResultPage() {
    this.router.navigate(['/result']);
  }

  private init() {
    this.route.params.subscribe((params) => {
      this.quizService.playerName = params['playerName'];
      this.playerName = params['playerName'];
      this.categoryName = params['categoryName'];
    });
    this.categoryService
      .getCategoryByName(this.categoryName)
      .subscribe((response: Category[]) => {
        this.quizService.setCategory(response[0]);
      });
  }
}
